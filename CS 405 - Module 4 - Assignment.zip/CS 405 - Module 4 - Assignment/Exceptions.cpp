// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <exception> //For std::exception

class customExcept : public std::exception
{ // Custom Exception class to create excption
public:
  virtual const char *what() const throw()
  {
    return "Custom Exception was here";
  }
};

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
  throw std::invalid_argument("Invalid Argument Exception"); // Throws an invalid argument exception

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}
void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  try // Wraps do_even_more_custom_application_logic() in a try
  {
    if (do_even_more_custom_application_logic())
    {
      std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
    }
  }
  catch (const std::exception &e)
  { // Catches exceptions that are thrown
    std::cerr << "Error: " << e.what() << std::endl;
  }

  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explictly in main

  throw customExcept();

  std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception
  if (den == 0.0)
  { // Checks if denominator is a zero before dividing
    throw std::runtime_error("Tried to divide by zero");
  }
  return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;

  try
  {
    auto result = divide(numerator, denominator);
    std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch (const std::exception &e)
  { // Catches exceptions that are thrown
    std::cerr << "Error: " << e.what() << std::endl;
  }
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception
  //  that wraps the whole main function, and displays a message to the console.
  try
  {
    do_division();
    do_custom_application_logic();
  }
  catch (const customExcept &e)//Catch Custom Exception
  {
    std::cerr << "Custom Error Except: " << e.what() << std::endl;
  }
  catch (const std::exception &e)//Catch std::exception
  {
    std::cerr << "Error: " << e.what() << std::endl;
  }
  catch (...){//Catch uncaught exception
    std::cerr << "Unknown Error Caught"<< std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
